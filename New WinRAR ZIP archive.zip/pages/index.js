import Features from "@/components/templates/index/Features";
import Homes from "@/components/templates/index/Homes";
import Story from "@/components/templates/index/Story";
import React from "react";

function index() {
  
  return (
    <>
      <Features />
      <Story />
      <Homes />
       
     
    </>
  );
}

export default index;
