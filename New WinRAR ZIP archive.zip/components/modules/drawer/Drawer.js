import React, { useEffect } from 'react';  
import styles from './drawer.module.css';   
import Link from 'next/link';  

const Drawer = ({ isOpen, onClose }) => {  
  useEffect(() => {  
    // Toggle body overflow style based on drawer open state  
    document.body.style.overflow = isOpen ? 'hidden' : 'auto';  

    // Cleanup effect to reset overflow when component unmounts or isOpen changes  
    return () => {  
      document.body.style.overflow = 'auto';  
    };  
  }, [isOpen]);  

  return (  
    <div className={`${styles.drawer} ${isOpen ? styles.open : ''}`}>  
      <button className={styles.closeBtn} onClick={onClose} style={{ padding: "20px", fontSize: "20px" }}>  
        بستن  
      </button>  
      <div className={styles.content} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>  
        <h2>خوش آمدید</h2>  
        <Link style={{ textDecoration: "none", color: "black" }} href={"#"}>درباره ما</Link>  
        <Link style={{ textDecoration: "none", color: "black" }} href={"#"}>سفارش کالا</Link>  
        <Link style={{ textDecoration: "none", color: "black" }} href={"#"}>تماس با ما</Link>  
        <Link style={{ textDecoration: "none", color: "black" }} href={"#"}>مشاوره</Link>  
      </div>  
    </div>  
  );  
};  

export default Drawer;