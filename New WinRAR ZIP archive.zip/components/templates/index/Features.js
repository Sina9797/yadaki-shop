import React from "react";
import "@fortawesome/fontawesome-svg-core/styles.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { config } from "@fortawesome/fontawesome-svg-core";
import {
  faBarChart,
  faKey,
  faLock,
  faMapMarker,
  faTools,
  faTrophy,
} from "@fortawesome/free-solid-svg-icons";
config.autoAddCss = false;

function Features() {
  return (
    <div className="featurs">
      <div className="featur">
        <span className="featur__icon">
          <FontAwesomeIcon icon={faTools} />
        </span>
        <h4 className="u-heading--dark">شرکت لوازم یدکی کروز</h4>
        <p className="u-paragraph">
          این شرکت یکی از قوی ترین شرکت های لوازم یدکی محسوب می شود. شاید بارها
          این کلمه به گوشتان خورده باشد اما توجهی به آن نکردید به طور مثال آینه
          پژو 207 کروز و محصولاتی از این قبیل این شرکت به قطع هم مطمئن و هم
          ضمانت کیفیت خوبی دارند.فروشگاه یدک فیت ارتباط مستقیم با این شرکت دارد
          و محصولات کروز را به شما با قیمتی کمتر از سایر عمده فروشان می فروشد.
        </p>
      </div>

      <div className="featur">
        <span className="featur__icon">
          <FontAwesomeIcon icon={faTools} />
        </span>
        <h4 className="u-heading--dark">شرکت تولیدی امکو</h4>
        <p className="u-paragraph">
          حتما نام امکو را شنیدید یکی از بهترین برند لوازم یدکی خودرو به خصوص در
          زمینه خرید برف پاک کن ، برف پاک کن های برند امکو و سایر محصولات امکو
          از کیفیت و قیمت مناسبی برخوردار است. لازم به ذکر است که تمام محصولات
          امکو به خصوص تیغه برف پاک کن های آن در فروشگاه یدک فیت به فروش می رسد.
          عمده فروشی لوازم یدکی خودرو یدک فیت ارتباط مستقیم با تمام تولید
          کنندگان برتر دنیا دارند. و همین دلیل موجب محبوبیت بین مردم و آن ها
          است.
        </p>
      </div>
      <div className="featur">
        <span className="featur__icon">
          <FontAwesomeIcon icon={faTools} />
        </span>
        <h4 className="u-heading--dark">شرکت تولیدی لوازم یدکی امیر نیا</h4>
        <p className="u-paragraph">
          این شرکت واقع در شهر تبریز است و از سال 69 فعالیت خود را در این زمینه
          شروع کردند.این گروه تعداد زیادی محصول تولید کرده است. که همین تعدا
          بالای محصولات با کیفیت و مقرون به صرفه آن سبب شد تا امروز جز 10 برند
          برتر لوازم یدکی شناخته شود.
        </p>
      </div>
      <div className="featur">
        <span className="featur__icon">
          <FontAwesomeIcon icon={faTools} />
        </span>
        <h4 className="u-heading--dark">شرکت عظام غول لوازم یدکی</h4>
        <p className="u-paragraph">
          تولیدکنندگانی مانند عظام و ایساکو جز بهترین تولید کنندگان برتر ایران
          هستند که شما می توانید محصولات عظام را در فروشگاه یدک فیت بیابید.و
          سفارش خودتان را ثبت کنید.
        </p>
      </div>
      <div className="featur">
        <span className="featur__icon">
          <FontAwesomeIcon icon={faTools} />
        </span>
        <h4 className="u-heading--dark">شرکت ایساکو</h4>
        <p className="u-paragraph">
          همانطور که در قسمت بالا گفتیم شرکت ایساکو جز بهترین شرکت های تولیدی در
          ایران می باشد.این شرکت در سال 82 شروع به کار کرد و پیشرفت خوبی هم در
          این زمینه داشت و هنوز که هنوزه مردم با این برند آشنا هستند.و برای خرید
          وقتی نام ایساکو بیاید بدون درنگ خرید می کنند.
        </p>
      </div>
      <div className="featur">
        <span className="featur__icon">
          <FontAwesomeIcon icon={faTools} />
        </span>
        <h4 className="u-heading--dark">شرکت لوازم یدکی رفیع نیا</h4>
        <p className="u-paragraph">
        یکی دیگر از مارک های خوب لوازم یدکی خودرو در کشور برند رفیع نیا است.این شرکت از سال 79 در تبریز شروع به فعالیت کرد . شما می توانید برای تهیه انواع محصولات این شرکت با فروشگاه یدک فیت تماس بگیرید.

این شرکت علاوه بر تولید محصولات با کیفیت از قیمت مناسبی هم برخوردار است.
        </p>
      </div>
    </div>
  );
}

export default Features;
