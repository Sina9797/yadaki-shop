import { useRouter } from "next/router";
import React from "react";

import db from "./../../data/db.json";

function SingleHome() {
  const router = useRouter();
  const { id: homeID } = router.query;

  const home = db.homes.find((home) => home.id === Number(homeID));

  return (
    <div className="home-details">
      <div className="home-details-top">
        <div className="home-img">
          <img src={home?.img} alt="" />
        </div>
        <div className="home-interduce">
          <div className="home-title">
            <h1>
              <span>{home?.title}</span>
              <span>{home?.price.toLocaleString()} تومان</span>
            </h1>
          
          </div>
          <div className="home-review">
            <div className="home-review-top">
              <h2>معرفی محصول</h2>
              <p className="">
                <span>کد کالا: </span>
                <span>{home?.code}</span>
              </p>
            </div>
            <ul className="home-review-bottom">
              <li>
                <span>دسته بندی: </span>
                <span>{home?.title}</span>
              </li>
              <li>
                <span>برند: </span>
                <span>{home?.roomCount}</span>
              </li>
              <li>
                <span>قطعه:</span>
                <span>{home?.meterage}</span>
              </li>
              <li>
                <span>خودرو:</span>
                <span>ایرانی و خارجی</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="home-details-bottom">
        <div className="home-details-description">
          <p className="">توضیحات</p>
          <p className="">
          {home?.desc}.
          </p>
        </div>
      </div>
    </div>
  );
}

export default SingleHome;
