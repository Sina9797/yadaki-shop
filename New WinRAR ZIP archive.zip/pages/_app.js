import "@/styles/globals.css";
import Link from "next/link";
import { useState } from "react";
import Drawer from "@/components/modules/drawer/Drawer";
import { BsList } from "react-icons/bs";

export default function App({ Component, pageProps }) {
    const [isOpen, setIsOpen] = useState(false);  
  
    const toggleDrawer = () => {  
      setIsOpen(!isOpen);  
    };
  return (
    <div className="container">
      <div className="sidebar">
      <button onClick={toggleDrawer} style={{padding:"20px",fontSize:"20px"}}><BsList/></button>  
      <Drawer isOpen={isOpen} onClose={toggleDrawer} /> 
      </div>

      <header className="header">
       <span></span>
        <span></span>
        <h1 className="u-heading-1">با کیفیت ترین ها را آنلاین سفارش دهید</h1>
        <Link href="/homes" className="btn header__btn btn-brown">
          فروشگاه ما را مشاهده نمایید
        </Link>

        <p className="seeon__text">محبوب ترین ها</p>
        <figure className="seeon__box-img">
          <img src="/img/mega.jpg" alt="BBC" className="seeon__img" />
          <img src="/img/crouse.png" alt="BBC" className="seeon__img" />
          <img src="/img/isacoo.png" alt="BBC" className="seeon__img" />
          <img
            src="/img/mco.png"
            alt="BBC"
            className="seeon__img"
          />
        </figure>
      </header>

      <div className="real-tors">
        <p className="real-tors__tittle">سه برند برتر</p>
        <div className="real-tors__list">
          <img
             src="/img/isaco.png"
            alt="real-tors top 1"
            className="real-tors__img"
          />
          <div className="real-tors__details">
            <h3 className="u-heading-3 u-heading--white">ایساکو</h3>
           
          </div>

          <img
            src="/img/crouse.png"
            alt="real-tors top 2"
            className="real-tors__img"
          />
          <div className="real-tors__details">
            <h3 className="u-heading-3 u-heading--white">کروز</h3>
            
          </div>

          <img
            src="/img/saipa.jpg"
            alt="real-tors top 3"
            className="real-tors__img"
          />
          <div className="real-tors__details">
            <h3 className="u-heading-3 u-heading--white">سایپا یدک</h3>
            
          </div>
        </div>
      </div>

      <Component {...pageProps} />

      
      <div className="payin" style={{width:"100%",height:"100px",background:"red",display:"flex",alignItems:"center",justifyContent:"space-around",backgroundColor:"#808080",position:"absolute",bottom:"0",zIndex:"99999"}}>
      
         
         
           <Link href="#" style={{textDecoration:"none",color:"white"}}>
             درخواست قطعه
           </Link>
         
         
            <Link href="#" style={{textDecoration:"none",color:"white"}}>
             درباره ما
           </Link>
         
         
            <Link href="#" style={{textDecoration:"none",color:"white"}}>
             تماس با ما
           </Link>
         
         
            <Link href="#" style={{textDecoration:"none",color:"white"}}>
             درباره قطعات یدکی
           </Link>
         
         
            <Link href="#" style={{textDecoration:"none",color:"white"}}>
             شرایط همکاری
           </Link>
           
       
      </div>
    </div>
  );
}
