import React, { useEffect, useState } from "react";  
import db from "./../../data/db.json";  
import Home from "@/components/modules/Home";  

function Index() {  
  const [search, setSearch] = useState("");  
  const [sort, setSort] = useState("-1");  
  const [homes, setHomes] = useState([...db.homes]);  

  useEffect(() => {  
    const newHomes = db.homes.filter((home) => home.title.includes(search));  
    setHomes(newHomes);  
  }, [search]);  

  useEffect(() => {  
    switch (sort) {  
      case "price": {  
        const newHomes = [...homes].sort((a, b) => a.price - b.price);  
        setHomes(newHomes);  
        break;  
      }  
      default: {  
        setHomes([...db.homes]);  
        break;  
      }  
    }  
  }, [sort]);  

  return (  
    <div className="home-section" id="houses">  
      <div className="home-filter-search">  
        <div className="home-filter">  
          <select defaultValue={sort} onChange={(e) => setSort(e.target.value)}>  
            <option value="-1">انتخاب کنید</option>  
            <option value="price">بر اساس قیمت</option>  
          </select>  
        </div>  
        <div className="home-search">  
          <input  
            type="text"  
            value={search}  
            onChange={(e) => setSearch(e.target.value)}  
            placeholder="جستجو کنید"  
          />  
        </div>  
      </div>  

      <div className="homes">  
        {homes.length > 0 ? (  
          homes.map((home) => <Home key={home.id} {...home} />)  
        ) : (  
          <p>نتیجه‌ای یافت نشد</p> // "No results found" in Persian  
        )}  
      </div>  
    </div>  
  );  
}  

export default Index;