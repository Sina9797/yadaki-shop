import Link from "next/link";
import React from "react";

function Home({ title, id, price, meterage, roomCount, img }) {
  return (
    <div className="card">
      <img src={img} alt="House 6" className="card__img" />
      <h5 className="card__title">{title}</h5>
      <span className="card__like">
        
      </span>
      <div className="card__details">
        <span className="">
        
        </span>
        <p className="card__text">لوازم یدکی</p>
        <span className="">
        
        </span>
        <p className="card__text">{roomCount} برند</p>
        <span className="">
        
        </span>
        <p className="card__text">{meterage}</p>
        <span className="">
        
        </span>
        <p className="card__text">{price.toLocaleString()} میلیون</p>
      </div>

      <Link href={`/homes/${id}`} className="btn btn-brown btn-card">
        مشاهده کالا
      </Link>
    </div>
  );
}

export default Home;
