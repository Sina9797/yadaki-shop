import React from "react";

function Story() {
  return (
    <>
      <div className="story__pictures"></div>

      <div className="story__content">
        <h2 className="u-heading--dark u-heading-2 u-my-small">
          &rdquo;بهترین لوازم یدکی&ldquo;
        </h2>

        <p className="story__text u-mb-medium">
          شما چه بخواهید یک عدد لوازم یدکی برای خودرو خود بخرید چه بخواهید برای
          خرید عمده لوازم یدکی اقدام کنید باید در هر صورت بهترین برند و مارک
          لوازم یدکی خودرو را باید بشناسید. تا هم سرتان کلاه نرود و هم بهترین
          های لوازم یدکی خودرو را بشناسید.
        </p>

        <button className="btn btn-brown">کالای خود را انتخاب کنید</button>
      </div>
    </>
  );
}

export default Story;
